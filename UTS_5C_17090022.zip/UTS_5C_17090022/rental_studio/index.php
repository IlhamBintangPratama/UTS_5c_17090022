<!DOCTYPE html>
<html>
<?php
session_start();
require 'koneksi.php';
require '_partials/header.php';
require 'body.php';

 ?>
</html>