 		<div class="row">
		 <div class="col-lg-12">
		    <h1 class="page-header"><i class="fas fa-tachometer-alt"></i>
				Dashboard
			    <small>Admin</small>
				   </h1>
           <ol class="breadcrumb">
			   <li>
				   <a href="?page=Dashboard"><i class="fa fa-dashboard"></i>	Dashboard</a>
               </li>
             </ol>
             <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              SELAMAT DATANG DI A.R STUDIO 
            </div>
         </div>
        </div>