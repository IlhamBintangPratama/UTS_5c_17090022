<?php 
 session_start();
 require '../koneksi.php';
 ?>
<!DOCTYPE html>
<html lang="en" class="perfect-scrollbar-on">
  <?php
    require 'models/header.php';
    // require 'cek_sesi.php';
  ?>
  <?php

    require 'body.php';
  ?>
</html>