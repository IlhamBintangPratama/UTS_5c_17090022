$(document).ready(function(){
$('#dtHorizontalVerticalScrollExample').DataTable({
	"scrollX":true,
	"scrollY":"500px",
	"scrollCollapse":true,
});
$('dataTables_length').addClass('bs-select');
});

btn.onclick = function(){
	console.log('yes','no')
}