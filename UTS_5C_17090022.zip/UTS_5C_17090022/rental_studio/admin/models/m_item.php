<?php 
class Item{
	include $mysqli;
	function __construct($conn){
		
	}
}
?>