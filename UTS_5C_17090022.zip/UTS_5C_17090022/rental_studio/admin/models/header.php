<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Halaman Admin - KOST.ID</title>
    <link href="include/css/bootstrap.css" rel="stylesheet">
    <link href="include/css/sb-admin.css" rel="stylesheet">
    
    <link rel="stylesheet" href="include/font-awesome/css/all.min.css">
    <link href="admin.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Unlock" />
    <link rel="stylesheet" type="text/css" href="include/css/dataTables.bootstrap4.min.css"/>
    <link rel="stylesheet" type="text/css" href="include/css/responsive.bootstrap4.min.css"/>
</head>