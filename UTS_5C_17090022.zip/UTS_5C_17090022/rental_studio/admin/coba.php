<?php 
class coba{
	
}
 ?>
