<?php 
	include './koneksi.php';
	
 ?>

<div class="footer">
	<div class="container">
	<div class="row">
		
		<div class="col-md-5 col-sm-6 mt-3 ml-5">
			<div class="">
				<h4>Lihat Kami Di</h4>
					<div class="fa-2x">
						<a href="#" class="nav-link2 fab fa-facebook-square"></a>
						<!-- <a class="fab fa-twitter-square"></a> -->
						<a href="#" class="nav-link2 fab fa-whatsapp"></a>
						<a href="#" class="nav-link2 fab fa-instagram"></a>					
					</div>
			</div>				
		</div>
		<div class="col-md- col-sm-6 mt-3 mb-2 mr-2">
			<h4>Contact</h4>
				<div>
					<span>Please contact Us below for more detail information.</span><br>
						<a target="new" href="https://wa.me/082119421058" class="nav-link2 fas fa-phone-alt mr-2 mb-2"></a><span>082119421058</span><br>
						<a target="new" href="Jl. Sumbrodo Gg. Asri III, Slerok, Tegal Timur, Kota Tegal" class="nav-link2 fas fa-home mb-2 mr-2"></a><span>Jl. Sumbrodo Gg. Asri III, Slerok, Tegal Timur, Kota Tegal</span>
				</div>
		</div>
	</div>
</div>
	<!-- .container -->
</div>
<div class="footer1 py-2">
	<p class="m-0 text-center text-white">Copyright &copy 2019-AR-Studio-Music</p>
</div>
<!-- Bootstrap core JavaScript -->
<script src="./assets/js/jquery.min.js"></script>
<script src="./assets/js/bootstrap.min.js"></script>
<script src="./assets/fontawesome-free/js/fontawesome.js"></script>
<script src="./assets/js/script.js"></script>
<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>